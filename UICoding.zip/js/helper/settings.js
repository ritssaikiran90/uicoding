/**
 * This file holds the constants and colorcodes for cards
 */
var TotalCards = [1, 2, 3, 4, 5, 6, 7, 8, 9];

var cardColorCodes = ["#333333", "#72C3DC", "#BFBFBF", "#EFEFEF", "#2F454E", "#2F454E", "#6F98A8", "#BFBFBF", "#6F98A8"]